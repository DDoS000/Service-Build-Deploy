class UnexpectedRelationshipState(Exception):
    pass
