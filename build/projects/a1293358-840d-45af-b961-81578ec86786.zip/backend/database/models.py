from auth.models import *
from post.models import *
from comment.models import *
from notification.models import *
from chat.models import *

# Empty function used by Alembic to discover database tables
load = lambda: None
