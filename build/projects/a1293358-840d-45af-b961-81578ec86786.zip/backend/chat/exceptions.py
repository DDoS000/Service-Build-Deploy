class NonExistentChatGroup(Exception):
    pass
